# I've fallen

A visual novel created with renpy.

# GUI

The project is created with a custom resolution of 800x450px, because renpy likes 16:9 aspect ratio.

All the GUI sizing and spacing is better left unchanged, since it's easy to mess up. Default spacings are ok.

# Autorefresh mode

To run the project in autorefresh mode, open with renpy and press Shift + R. You can now edit the script, GUI and other stuff, and the game window will detect file changes and autorefresh.

## Notice

This project was created by danaidraDev, 2021.

This project was created with the [Ren'Py Visual Novel Engine](https://www.renpy.org/).

You can see the license info [here](https://www.renpy.org/doc/html/license.html).